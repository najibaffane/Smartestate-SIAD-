import os 
import joblib

def load_model():

    model_path = os.path.join(os.path.dirname(__file__),'models','model.pkl')
    model = joblib.load(model_path)
    return model

