from rest_framework import serializers
from . import models


class PropertySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Property
        fields = '__all__'



class ApartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Apartment
        fields = '__all__'


        
class VillaSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Villa
        fields = '__all__'



class GroundSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Ground
        fields = '__all__'


class AnnonceSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Annonce
        fields = '__all__'


class ProfileSerializer(serializers.ModelSerializer):
    first_name=serializers.CharField(source='user.first_name')
    last_name=serializers.CharField(source='user.last_name')
    class Meta:
        model = models.UserProfile  
        fields = [ 'phone', 'adress','first_name', 'last_name']

class FavorisSerializer(serializers.ModelSerializer):
    class Meta:
        model =models.Favoris
        fields='__all__'


# class AppartementEstimatorSerializer(serializers.Serializer):
#     bedrooms = serializers.FloatField(required=True)
#     bathrooms = serializers.FloatField(required=True)
#     sqft_living = serializers.FloatField(required=True)
#     floors = serializers.FloatField(required=True)
#     waterfront = serializers.FloatField(required=True)
#     view = serializers.FloatField(required=True)
#     condition = serializers.FloatField(required=True)
#     price = serializers.FloatField(read_only=True)


class EstimatorSerializer(serializers.Serializer):
    building_construction_year = serializers.FloatField(required=True)
    building_total_floors = serializers.FloatField(required=True)
    apartment_floor = serializers.FloatField(required=True)
    apartment_rooms = serializers.FloatField(required=True)
    apartment_bedrooms = serializers.FloatField(required=True)
    apartment_bathrooms = serializers.FloatField(required=True)
    apartment_total_area = serializers.FloatField(required=True)
    apartment_living_area = serializers.FloatField(required=True)
    country_encoded = serializers.FloatField(required=True)
    location_encoded = serializers.FloatField(required=True)

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.UserProfile
        fields = ['phone', 'adress', 'birthday', 'user_type', 'user']
        
    def create(self, validated_data):
        user = validated_data.get('user')
        if not user:
            raise serializers.ValidationError("User is required")
        return models.UserProfile.objects.create(**validated_data)