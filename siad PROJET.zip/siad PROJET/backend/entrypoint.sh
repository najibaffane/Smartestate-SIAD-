#!/bin/sh
echo "waiting for postgres db..."
./wait-for-it.sh db:5432 
echo "postgres is up"
echo "running migrations..."    
python manage.py migrate
echo "migrations completed"
echo "starting server..."   
python manage.py runserver "0.0.0.0:8000"