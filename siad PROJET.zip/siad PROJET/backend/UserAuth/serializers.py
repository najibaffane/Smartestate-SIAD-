from djoser.serializers import UserCreateSerializer as BaseUserCreateSerializer, UserSerializer as UserBaseSerialize
from rest_framework import serializers
from django.contrib.auth import get_user_model

class UserCreateSerializer(BaseUserCreateSerializer):
    class Meta(BaseUserCreateSerializer.Meta):
        model = get_user_model()
        fields = ['id', 'username', 'password', 'email', 'first_name', 'last_name']
        extra_kwargs = {
            'password': {'write_only': True},
            'first_name': {'required': True},
            'last_name': {'required': True},
            'username': {'required': True},
            'email': {'required': True}
        }

    def validate(self, attrs):
        # Validate that all required fields are present
        required_fields = ['first_name', 'last_name', 'username', 'email']
        for field in required_fields:
            if not attrs.get(field):
                raise serializers.ValidationError({field: f'Le champ {field} est requis'})
        return super().validate(attrs)

    def validate_email(self, value):
        if get_user_model().objects.filter(email=value).exists():
            raise serializers.ValidationError("Cette adresse email est déjà utilisée.")
        return value


class UserSerializer(UserBaseSerialize):
    class Meta(UserBaseSerialize.Meta):
        model = get_user_model()  # Explicitly set the user model
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

