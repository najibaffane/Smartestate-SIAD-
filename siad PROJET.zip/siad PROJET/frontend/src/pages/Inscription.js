import React from 'react';
import Navbar from '../composants/Navbar';
import { Link, useNavigate } from 'react-router-dom';
import { set, useForm } from 'react-hook-form';
import axios from 'axios';
import { useState } from 'react';
import backgroundImage from '../assets/vecteezy_dark-abstract-background-black-overlap-vector_10630941.jpg';

const Inscription = () => {
    const navigate = useNavigate();
    const input_class = "p-2 border text-gray-600 font-semibold outline-none w-[100%] focus:border-[#333] rounded-lg";
    const [userType, setUserType] = useState('AGENCE');
    const handleUserTypeChange = (event) => {
        setUserType(event.target.value);
    };
    const [errorMessage, setErrorMessage] = useState('');
    const [SuccesMsg, setSucessMsg] = useState('');
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const {
        handleSubmit,
        register,
        formState: { errors },
        watch
    } = useForm();
    
    const onSubmit = async (data) => {
        if (data.password !== data.repassword) {
            setErrorMessage("Les mots de passe ne correspondent pas.");
            return;
        }

        try {
            // Première requête pour créer l'utilisateur
            const responseUser = await axios.post('http://127.0.0.1:8000/auth/users/', {
                username: data.username,
                password: data.password,
                email: data.email,
                first_name: data.nom,
                last_name: data.prenom
            });
            
            if (responseUser.data && responseUser.data.id) {
                try {
                    // Get token first
                    const tokenResponse = await axios.post('http://127.0.0.1:8000/auth/jwt/create/', {
                        username: data.username,
                        password: data.password
                    });

                    const token = tokenResponse.data.access;

                    // Format birthday
                    const formattedBirthday = data.naissance ? new Date(data.naissance).toISOString().split('T')[0] : null;
                    
                    // Create customer profile with token
                    const customerResponse = await axios.post(
                        'http://127.0.0.1:8000/store/customer/',
                        {
                            phone: data.telephone,
                            adress: data.adresse,
                            birthday: formattedBirthday,
                            user_type: userType || 'PARTICULIER',
                            user: responseUser.data.id
                        },
                        {
                            headers: {
                                'Authorization': `JWT ${token}`,
                                'Content-Type': 'application/json'
                            }
                        }
                    );
                    
                    setErrorMessage('');
                    setSucessMsg("Votre compte a été bien créé vous pouvez vous connecter !");
                    setShowSuccessModal(true);
                    
                    setTimeout(() => {
                        navigate('/connexion');
                    }, 2000);
                } catch (customerError) {
                    console.error("Erreur détaillée:", customerError.response?.data);
                    const errorDetail = typeof customerError.response?.data === 'object' 
                        ? Object.entries(customerError.response.data)
                            .map(([key, value]) => `${key}: ${value}`)
                            .join(', ')
                        : "Erreur lors de la création du profil.";
                    setErrorMessage(errorDetail);
                }
            }
        } catch (error) {
            const errorMsg = error.response?.data 
                ? Object.entries(error.response.data)
                    .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
                    .join('\n')
                : "Une erreur est survenue lors de l'inscription.";
            setErrorMessage(errorMsg);
        }
    };

    // Success Modal Component
    const SuccessModal = () => {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white p-8 rounded-2xl shadow-2xl max-w-md w-full text-center relative">
                    <button 
                        onClick={() => setShowSuccessModal(false)}
                        className="absolute top-4 right-4 text-gray-600 hover:text-gray-900"
                    >
                        ✕
                    </button>
                    
                    <div className="flex justify-center mb-6">
                        <svg 
                            xmlns="http://www.w3.org/2000/svg" 
                            width="100" 
                            height="100" 
                            viewBox="0 0 24 24" 
                            fill="none" 
                            stroke="green" 
                            strokeWidth="1.5" 
                            strokeLinecap="round" 
                            strokeLinejoin="round"
                        >
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </div>

                    <h1 className="text-3xl font-bold text-gray-800 mb-4">
                        Compte créé avec succès !
                    </h1>

                    <p className="text-gray-600 mb-6">
                        Félicitations ! Votre compte a été bien créé. Vous pouvez maintenant vous connecter.
                    </p>

                    <div className="flex justify-center">
                        <Link 
                            to="/connexion"
                            className="bg-[#333] text-white py-3 px-6 rounded-lg hover:bg-opacity-90 transition duration-300"
                        >
                            Se Connecter
                        </Link>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className='flex flex-col gap-40 min-h-screen' style={{
            backgroundImage: `url(${backgroundImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            paddingTop: '120px'
        }}>
            <Navbar />
            <div className="bg-white p-6 shadow-2xl w-[60%] max-[768px]:w-[90%] m-auto border-t-4 border-[#333] rounded-lg mb-8">
                <form className='flex flex-col gap-6' onSubmit={handleSubmit(onSubmit)}>
                    <div className="flex flex-col gap-2">
                        <h1 className='text-center font-bold text-[#333] text-2xl'>Créer un compte</h1>
                        {errorMessage && (
                            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                                <strong className="font-bold">Erreur : </strong>
                                <span className="block sm:inline whitespace-pre-line">{errorMessage}</span>
                            </div>
                        )}
                        {SuccesMsg && (<p className='text-green-500 font-bold text-center'>{SuccesMsg}</p>)}
                    </div>
                    <div className="grid grid-cols-2 gap-6 max-[768px]:grid-cols-1">
                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Nom *</label>
                            <input className={input_class}
                                type="text"
                                {...register("nom", { 
                                    required: "Le nom est requis" 
                                })}
                                placeholder="Votre nom"
                            />
                            {errors.nom && <p className='text-red-500'>{errors.nom.message}</p>}
                        </div>

                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Prénom *</label>
                            <input className={input_class}
                                type="text"
                                {...register("prenom", { 
                                    required: "Le prénom est requis" 
                                })}
                                placeholder="Votre prénom"
                            />
                            {errors.prenom && <p className='text-red-500'>{errors.prenom.message}</p>}
                        </div>

                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Nom d'utilisateur *</label>
                            <input className={input_class}
                                type="text"
                                placeholder="Votre nom d'utilisateur.."
                                {...register('username', {
                                    required: 'Le nom d\'utilisateur est requis',
                                    minLength: { value: 6, message: "Le nom d'utilisateur doit contenir au moins 6 caractères" },
                                })}
                            />
                            {errors.username && <p className='text-red-500'>{errors.username.message}</p>}
                        </div>
                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Email *</label>
                            <input className={input_class}
                                type="email"
                                placeholder="Votre email.."
                                {...register('email', {
                                    required: 'Le champ Email est requis',
                                    pattern: {
                                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                                        message: 'Adresse email invalide',
                                    },
                                })}
                            />
                            {errors.email && <p className='text-red-500'>{errors.email.message}</p>}
                        </div>
                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Téléphone *</label>
                            <input className={input_class}
                                type="tel"
                                placeholder="Votre numéro de téléphone.."
                                {...register('telephone', {
                                    required: 'Le champ Téléphone est requis',
                                    pattern: {
                                        value: /^\d+$/,
                                        message: 'Le numéro de téléphone doit contenir uniquement des chiffres',
                                    },
                                })}
                            />
                            {errors.telephone && <p className='text-red-500'>{errors.telephone.message}</p>}
                        </div>
                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Mot de passe *</label>
                            <input className={input_class}
                                type="password"
                                placeholder="Donner un mot de passe.."
                                {...register('password', {
                                    required: 'Le champ Mot de passe est requis',
                                    minLength: { value: 8, message: 'Le mot de passe doit contenir au moins 8 caractères' },
                                })}
                            />
                            {errors.password && <p className='text-red-500'>{errors.password.message}</p>}
                        </div>
                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Confirmer le mot de passe *</label>
                            <input className={input_class}
                                type="password"
                                placeholder="Rétaper le mot de passe.."
                                {...register('repassword', {
                                    required: 'Le champ Confirmer le mot de passe est requis',
                                })}
                            />
                            {errors.repassword && <p className='text-red-500'>{errors.repassword.message}</p>}
                        </div>

                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Date de naissance</label>
                            <input className={input_class} type="date" {...register('naissance')} placeholder="Votre date de naissance.." />
                        </div>
                        <div className='flex flex-col gap-1'>
                            <label className="text-[#333] font-bold">Adresse *</label>
                            <input className={input_class} 
                                type="text" 
                                {...register('adresse', { 
                                    required: 'Le champ Adresse est requis' 
                                })} 
                                placeholder="Votre adresse actuelle.." 
                            />
                            {errors.adresse && <p className='text-red-500'>{errors.adresse.message}</p>}
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <span className='text-[#333] font-bold'>Type d'utilisateur *</span>
                        <select className='bg-white cursor-pointer border p-2 rounded-lg' value={userType}
                            onChange={handleUserTypeChange}>
                            <option value="AGENCE">AGENCE</option>
                            <option value="PARTICULIER">PARTICULIER</option>
                        </select>
                    </div>
                    <div className="flex gap-2 items-center">
                        <input
                            type='checkbox'
                            {...register('acceptRules', { required: 'Vous devez accepter les règles' })}
                            className='cursor-pointer'
                        />
                        <span className='text-[#333]'>J'accepte les règles de l'utilisation</span>
                    </div>
                    {errors.acceptRules && <p className='text-red-500'>{errors.acceptRules.message}</p>}

                    <div className="text-center">
                        <p>Vous avez déjà un compte? <Link to="/connexion" className='font-bold underline text-[#333]'>cliquez ici</Link></p>
                    </div>

                    <input
                        type='submit'
                        className='p-3 bg-[#333] cursor-pointer hover:bg-white border-2 border-[#333] hover:text-[#333] text-white font-bold rounded-full w-full transition duration-300 ease-in-out transform hover:scale-105'
                        value="Envoyer"
                    />
                </form>
            </div>

            {/* Success Modal Render Condition */}
            {showSuccessModal && <SuccessModal />}
        </div>
    );
};

export default Inscription;