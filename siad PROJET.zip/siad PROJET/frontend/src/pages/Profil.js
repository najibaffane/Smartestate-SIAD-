import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Navbar from '../composants/Navbar';
import User_Icon from '../assets/user_icon.png'
import axios from 'axios';

const Profil = () => {
    const input_class = "p-3 border border-gray-300 rounded-md text-gray-700 font-semibold outline-none w-full focus:border-[#333]";
    const { userId } = useParams();
    const userIdInt = parseInt(userId);

    const [nom, setNom] = useState("");
    const handleNomChange = (event) => setNom(event.target.value);
    
    const [prenom, setPrenom] = useState("");
    const handlePrenomChange = (event) => setPrenom(event.target.value);
    
    const [userName, setUsername] = useState("");
    const [Email, setEmail] = useState("");
    const handleEmailchange = (event) => setEmail(event.target.value);

    const [adresse, setAdresse] = useState("");
    const handAdressechange = (event) => setAdresse(event.target.value);

    const [phone, setPhone] = useState("");
    const handlePhonechange = (event) => setPhone(event.target.value);

    const [errorMsg, setErrorMessage] = useState("");
    const [succesMsg, setSuccesMsg] = useState("");

    const recuperer_donnees = async () => {
        try {
            const token = localStorage.getItem('token');
            if (!token) return;

            const response = await axios.get('http://127.0.0.1:8000/auth/users/me/', {
                headers: { Authorization: `JWT ${token}` },
            });

            setNom(response.data.first_name);
            setPrenom(response.data.last_name);
            setUsername(response.data.username);
            setEmail(response.data.email);

            const donnes_profil = await axios.get(`http://127.0.0.1:8000/store/customer/${response.data.id}/`);
            setAdresse(donnes_profil.data.adress);
            setPhone(donnes_profil.data.phone);

        } catch (error) {
            console.log("Erreur de la récupération des données de l'utilisateur", error);
        }
    };

    useEffect(() => {
        recuperer_donnees();
    }, []);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setErrorMessage('');
        const token = localStorage.getItem('token');
        if (!nom || !prenom || !userName || !Email || !phone || !adresse) {
            setErrorMessage("Vous devez remplir tout les champs !");
            return;
        }

        try {
            await axios.put('http://127.0.0.1:8000/auth/users/me/', {
                first_name: nom,
                last_name: prenom,
                username: userName,
                email: Email,
            }, {
                headers: { Authorization: `JWT ${token}` },
            });

            setSuccesMsg("Votre profil a été modifié avec succès !");
        } catch (error) {
            console.log("Erreur lors de la modification des données utilisateur", error);
        }
    };

    return (
        <div className="flex flex-col gap-32 bg-gray-100 min-h-screen pt-40"> {/* Added pt-20 for top padding */}
            <Navbar />
            <form className="flex justify-center items-center mb-12" onSubmit={handleSubmit}>
                <div className="relative bg-white p-8 px-10 w-[60%] shadow-lg rounded-lg border-t-4 border-[#333]">
                    <div className="absolute left-[50%] transform -translate-x-[50%] top-[-40px]">
                        <img className="w-28 h-28 rounded-full border-4 border-white shadow-lg" src={User_Icon} alt="User Icon" />
                    </div>
                    <div className="flex flex-col gap-6 mt-12">
                        {errorMsg && <span className="text-red-500 bg-red-100 p-2 text-center font-semibold rounded-md">{errorMsg}</span>}
                        {succesMsg && <span className="text-green-500 bg-green-100 p-2 text-center font-semibold rounded-md">{succesMsg}</span>}

                        <div className="flex gap-2 flex-col">
                            <label className="text-[#333] font-bold">Nom</label>
                            <input type="text" className={input_class} value={nom} onChange={handleNomChange} />
                        </div>
                        <div className="flex gap-2 flex-col">
                            <label className="text-[#333] font-bold">Prénom</label>
                            <input type="text" className={input_class} value={prenom} onChange={handlePrenomChange} />
                        </div>
                        <div className="flex gap-2 flex-col">
                            <label className="text-[#333] font-bold">Nom d'utilisateur</label>
                            <input type="text" className="p-3 border border-gray-300 rounded-md text-gray-700 font-semibold bg-gray-200 w-full cursor-not-allowed" disabled value={userName} />
                        </div>
                        <div className="flex gap-2 flex-col">
                            <label className="text-[#333] font-bold">Email</label>
                            <input type="email" className={input_class} value={Email} onChange={handleEmailchange} />
                        </div>
                        <div className="flex gap-2 flex-col">
                            <label className="text-[#333] font-bold">Téléphone</label>
                            <input type="number" className={input_class} value={phone} onChange={handlePhonechange} />
                        </div>
                        <div className="flex gap-2 flex-col">
                            <label className="text-[#333] font-bold">Adresse</label>
                            <input type="text" className={input_class} value={adresse} onChange={handAdressechange} />
                        </div>
                        <button type="submit" className="mt-10 w-full py-3 bg-[#333] text-white font-semibold rounded-md hover:bg-white hover:text-[#333] hover:border hover:border-[#333] transition-all duration-300">
                            Modifier
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default Profil;
