import React, { useState } from 'react';
import Navbar from '../composants/Navbar';
import axios from 'axios';
import backgroundImage from '../assets/vecteezy_dark-abstract-background-black-overlap-vector_10630941.jpg';

const Estimateur = () => {
  const [formData, setFormData] = useState({
    building_construction_year: '',
    building_total_floors: '',
    apartment_floor: '',
    apartment_rooms: '',
    apartment_bedrooms: '',
    apartment_bathrooms: '',
    apartment_total_area: '',
    apartment_living_area: '',
    country_encoded: '',
    location_encoded: ''
  });
  const [errorMsg, setErrorMessage] = useState("");
  const [prixEstimer, setPrixEstime] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8000/store/estimator/appartement/', formData);
      setPrixEstime(response.data.price);
    } catch (error) {
      console.error("Erreur lors de l'estimation:", error);
      setErrorMessage("Une erreur est survenue lors de l'estimation");
    }
  };

  return (
    <div style={styles.pageContainer}>
      <Navbar />
      <style>
        {`
          .estimate-button {
            width: 100%;
            padding: 12px;
            background-color: #333;
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s, transform 0.3s;
          }
          .estimate-button:hover {
            background-color: #555;
            transform: scale(1.05);
          }
        `}
      </style>
      <div style={styles.estimatorContainer}>
        <div style={styles.header}>
          <h1 style={styles.headerText}>Estimer le prix d'un appartement</h1>
          {errorMsg && <p style={styles.errorMessage}>{errorMsg}</p>}
        </div>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.gridContainer}>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Année de construction</label>
              <input
                type="number"
                style={styles.input}
                value={formData.building_construction_year}
                onChange={(e) => setFormData({...formData, building_construction_year: Number(e.target.value)})}
                placeholder="Année de construction"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Nombre total d'étages</label>
              <input
                type="number"
                style={styles.input}
                value={formData.building_total_floors}
                onChange={(e) => setFormData({...formData, building_total_floors: Number(e.target.value)})}
                placeholder="Nombre total d'étages"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Étage de l'appartement</label>
              <input
                type="number"
                style={styles.input}
                value={formData.apartment_floor}
                onChange={(e) => setFormData({...formData, apartment_floor: Number(e.target.value)})}
                placeholder="Étage de l'appartement"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Nombre de pièces</label>
              <input
                type="number"
                style={styles.input}
                value={formData.apartment_rooms}
                onChange={(e) => setFormData({...formData, apartment_rooms: Number(e.target.value)})}
                placeholder="Nombre de pièces"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Nombre de chambres</label>
              <input
                type="number"
                style={styles.input}
                value={formData.apartment_bedrooms}
                onChange={(e) => setFormData({...formData, apartment_bedrooms: Number(e.target.value)})}
                placeholder="Nombre de chambres"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Nombre de salles de bain</label>
              <input
                type="number"
                style={styles.input}
                value={formData.apartment_bathrooms}
                onChange={(e) => setFormData({...formData, apartment_bathrooms: Number(e.target.value)})}
                placeholder="Nombre de salles de bain"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Surface totale (m²)</label>
              <input
                type="number"
                style={styles.input}
                value={formData.apartment_total_area}
                onChange={(e) => setFormData({...formData, apartment_total_area: Number(e.target.value)})}
                placeholder="Surface totale"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Surface habitable (m²)</label>
              <input
                type="number"
                style={styles.input}
                value={formData.apartment_living_area}
                onChange={(e) => setFormData({...formData, apartment_living_area: Number(e.target.value)})}
                placeholder="Surface habitable"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Code pays</label>
              <input
                type="number"
                style={styles.input}
                value={formData.country_encoded}
                onChange={(e) => setFormData({...formData, country_encoded: Number(e.target.value)})}
                placeholder="Code pays"
                required
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Code localisation</label>
              <input
                type="number"
                style={styles.input}
                value={formData.location_encoded}
                onChange={(e) => setFormData({...formData, location_encoded: Number(e.target.value)})}
                placeholder="Code localisation"
                required
              />
            </div>
          </div>

          <button type="submit" className="estimate-button">
            Estimer le prix
          </button>
        </form>
      </div>
      {prixEstimer && (
        <div style={styles.resultContainer}>
          <p style={styles.resultLabel}>Prix estimé :</p>
          <p style={styles.resultPrice}>{parseInt(prixEstimer)} $</p>
        </div>
      )}
      <footer style={styles.footer}>
        <div style={styles.footerSection}>
          <h3 style={styles.footerHeading}>Tools</h3>
          <p>AI image generator</p>
          <p>AI video generator</p>
          <p>Image upscaler</p>
          <p>Background remover</p>
        </div>
        <div style={styles.footerSection}>
          <h3 style={styles.footerHeading}>Information</h3>
          <p>Pricing</p>
          <p>About us</p>
          <p>Jobs</p>
          <p>Events</p>
        </div>
        <div style={styles.footerSection}>
          <h3 style={styles.footerHeading}>Support</h3>
          <p>FAQ</p>
          <p>Contact</p>
        </div>
      </footer>
    </div>
  );
};

const styles = {
  pageContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    paddingTop: '50px',
  },
  estimatorContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: '16px',
    width: '60%',
    padding: '40px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    marginTop: '40px',
    marginBottom: '20px',
  },
  header: {
    textAlign: 'center',
    marginBottom: '20px',
  },
  headerText: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333',
  },
  errorMessage: {
    color: '#d9534f',
    backgroundColor: '#ffe5e5',
    padding: '10px',
    borderRadius: '4px',
    textAlign: 'center',
    marginTop: '10px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
  },
  gridContainer: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
    marginBottom: '20px',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
  },
  label: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#555',
    marginBottom: '5px',
  },
  input: {
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    outline: 'none',
    transition: 'border-color 0.3s, box-shadow 0.3s',
  },
  select: {
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    backgroundColor: '#fff',
    outline: 'none',
    cursor: 'pointer',
  },
  resultContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: '20px',
    padding: '20px',
    backgroundColor: 'rgba(240, 255, 240, 0.8)',
    borderRadius: '8px',
    boxShadow: '0 4px 10px rgba(0, 255, 0, 0.1)',
  },
  resultLabel: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333',
    marginRight: '10px',
  },
  resultPrice: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#28a745',
  },
  footer: {
    width: '100%',
    backgroundColor: '#333',
    color: '#fff',
    display: 'flex',
    justifyContent: 'space-around',
    padding: '20px 0',
    marginTop: 'auto',
  },
  footerSection: {
    textAlign: 'center',
  },
  footerHeading: {
    fontWeight: 'bold',
    marginBottom: '8px',
  },
};

export default Estimateur;
