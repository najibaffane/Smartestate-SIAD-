import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Navbar from '../composants/Navbar';
import axios from 'axios';

const USD_TO_DA = 135; // Conversion rate from USD to DA

const Annonce = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [Appartement, SetAppartement] = useState([]);
  const [Terrain, SetTerrain] = useState([]);
  const [Villa, SetVilla] = useState([]);
  const [Property, setProperty] = useState([]);
  const [annonce, setAnnonce] = useState([]);
  const [user_data, setUser] = useState([]);
  const [mainImage, setMainImage] = useState(null);
  const [currency, setCurrency] = useState('USD'); // State to track currency selection

  useEffect(() => {
    axios
      .get(`http://127.0.0.1:8000/store/property/${id}/`)
      .then((response) => {
        setProperty(response.data);
        setMainImage(response.data.img_1);

        axios
          .get(`http://127.0.0.1:8000/store/annonce/${id}/`)
          .then((response_annonce) => {
            setAnnonce(response_annonce.data);

            axios
              .get(`http://127.0.0.1:8000/store/customer/${response_annonce.data.Customer}/`)
              .then((response_user) => {
                // Ensure we set the user data correctly with matching field names
                setUser(response_user.data);
                console.log(response_user.data)
              })
              .catch((error) => {
                console.error("Erreur lors de la récupération des informations utilisateur:", error);
              });
          })
          .catch((error) => {
            console.error("Erreur lors de la récupération de l'annonce:", error);
          });

        if (response.data.type_propriete === "Villa") {
          axios
            .get(`http://127.0.0.1:8000/store/property/villa/${response.data.id}/`)
            .then((response_vil) => {
              SetVilla(response_vil.data);
            })
            .catch((error) => {
              console.error("Erreur lors de la récupération des informations de la villa:", error);
            });
        } else if (response.data.type_propriete === "Terrain") {
          axios
            .get(`http://127.0.0.1:8000/store/property/ground/${response.data.id}/`)
            .then((response_terr) => {
              SetTerrain(response_terr.data);
            })
            .catch((error) => {
              console.error("Erreur lors de la récupération des informations du terrain:", error);
            });
        } else if (response.data.type_propriete === "Appartement") {
          axios
            .get(`http://127.0.0.1:8000/store/property/appartement/${response.data.id}/`)
            .then((response_app) => {
              SetAppartement(response_app.data);
            })
            .catch((error) => {
              console.error("Erreur lors de la récupération des informations de l'appartement:", error);
            });
        }
      })
      .catch((error) => {
        console.error("Erreur lors de la récupération des informations de la propriété:", error);
      });
  }, []);

  const handleThumbnailClick = (image) => {
    setMainImage(image);
  };

  // Toggle currency between USD and DA
  const toggleCurrency = () => {
    setCurrency((prevCurrency) => (prevCurrency === 'USD' ? 'DA' : 'USD'));
  };

  // Calculate the price based on selected currency
  const displayPrice = currency === 'USD' ? 
    `$${Property.price}` : 
    `${(Property.price * USD_TO_DA).toLocaleString('fr-DZ')} DA`;

  return (
    <div className="min-h-screen flex flex-col items-center bg-gray-100 pt-28">
      <Navbar />
      <div className="w-full px-8 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left section with main image and details */}
          <div className="col-span-2 bg-white rounded-lg shadow-lg p-8">
            <div className="mb-6">
              <img className="rounded-lg w-full h-96 object-cover" src={mainImage} alt="Main property" />
            </div>

            {/* Thumbnail Gallery */}
            <div className="flex gap-4 overflow-x-auto mb-6">
              {[Property.img_1, Property.img_2, Property.img_3].map((img, index) => (
                <img
                  key={index}
                  className="h-24 w-32 rounded-lg shadow cursor-pointer object-cover transition hover:opacity-75"
                  src={img}
                  alt={`Property ${index + 1}`}
                  onClick={() => handleThumbnailClick(img)}
                />
              ))}
            </div>

            {/* Title, Price, and Currency Toggle */}
            <div className="text-left">
              <h2 className="text-3xl font-bold text-gray-800">{Property.title}, {Property.adress}</h2>
              <div className="flex items-center mt-2">
                <p className="text-green-600 text-2xl font-bold mr-4">{displayPrice}</p>
                <button 
                  onClick={toggleCurrency}
                  className="px-4 py-1 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 transition"
                >
                  {currency === 'USD' ? 'Afficher en DA' : 'Afficher en USD'}
                </button>
              </div>
            </div>

            {/* Property Details */}
            <div className="flex flex-wrap gap-4 mt-4 text-gray-700">
              {Property.type_propriete === "Appartement" && (
                <>
                  <p><i className="fas fa-bed mr-2"></i>{Appartement.rooms} Chambres</p>
                  <p><i className="fas fa-bath mr-2"></i>{Appartement.bathrooms} Salles de bain</p>
                  <p><i className="fas fa-building mr-2"></i>Étage : {Appartement.floors}</p>
                  <p><i className="fas fa-eye mr-2"></i>Vue : {Appartement.view}</p>
                </>
              )}
              {Property.type_propriete === "Villa" && (
                <>
                  <p><i className="fas fa-bed mr-2"></i>{Villa.rooms} Chambres</p>
                  <p><i className="fas fa-bath mr-2"></i>{Villa.bathrooms} Salles de bain</p>
                  <p><i className="fas fa-tree mr-2"></i>Jardin : {Villa.garden ? 'Oui' : 'Non'}</p>
                  <p><i className="fas fa-swimmer mr-2"></i>Piscine : {Villa.pool ? 'Oui' : 'Non'}</p>
                </>
              )}
              {Property.type_propriete === "Terrain" && (
                <p><i className="fas fa-landmark mr-2"></i>Type de terrain : {Terrain.Ground_type}</p>
              )}
            </div>

            {/* Property Description */}
            <h3 className="mt-8 font-bold text-xl text-gray-700">Description de la propriété</h3>
            <p className="text-gray-600 mt-4 leading-relaxed">{Property.description}</p>

            {/* Purchase Button */}
            <button className="mt-6 w-full bg-[#333] text-white py-3 rounded-lg font-bold hover:bg-opacity-80 transition">
              Acheter cette propriété
            </button>
          </div>
              
          {/* Right section with property and seller details */}
          <div className="space-y-4">
            {/* Property Details */}
            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
              <h4 className="text-lg font-bold text-gray-800 mb-4">Détails de la propriété</h4>
              <div className="text-gray-600 space-y-2">
                <p><strong>Type :</strong> {Property.type_propriete}</p>
                <p><strong>Adresse :</strong> {Property.adress}</p>
                <p><strong>Date :</strong> {annonce.publication_date}</p>
                <p><strong>Surface :</strong> {Property.area} m²</p>
                {/* Status button-style display */}
                <p>
                  <strong>État :</strong>
                  <span
                    className={`ml-2 px-3 py-1 rounded-full text-white text-sm font-semibold ${
                      Property.state === "DISPONIBLE" ? "bg-green-500" : "bg-red-500"
                    }`}
                  >
                    {Property.state === "DISPONIBLE" ? "Disponible" : "Indisponible"}
                  </span>
                </p>
              </div>
            </div>

            {/* Seller Details */}
            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
              <h4 className="text-lg font-bold text-[#333] mb-4">Informations du vendeur</h4>
              <div className="text-[#333] space-y-3">
                {/* Display the seller's information correctly */}
                <p><i className="fas fa-user-tie mr-2 text-[#333]"></i><strong>Nom :</strong> {user_data.first_name} {user_data.last_name}</p>
                <p><i className="fas fa-map-marker-alt mr-2 text-[#333]"></i><strong>Adresse :</strong> {user_data.adress}</p>
                <p><i className="fas fa-phone-alt mr-2 text-[#333]"></i><strong>Téléphone :</strong> {user_data.phone}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Annonce;
