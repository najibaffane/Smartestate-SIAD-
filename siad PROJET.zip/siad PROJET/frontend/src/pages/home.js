import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom'; 
import Navbar from "../composants/Navbar";
import houseImage from '../assets/—Pngtree—3d modern house isolated_14639229.png';
import predictionImage from '../assets/—Pngtree—3d modern house isolated_14639229.png';
import AOS from 'aos';
import 'aos/dist/aos.css';

const HomePage = ({ gradientStart = '#ffffff', gradientEnd = '#333' }) => {
    const navigate = useNavigate();

    useEffect(() => {
        AOS.init({ duration: 1000, once: true });
    }, []);

    const handleLancerClick = () => {
        navigate('/connexion');
    };

    const handleParcourirClick = () => {
        navigate('/pages/Acceuil');
    };

    return (
        <div className="home-page">
            <Navbar />

            <div className="px-3 lg:px-6 py-16">
                <section
                    className="header-section w-full text-center lg:flex lg:items-center lg:justify-between relative overflow-hidden"
                    style={{ height: '90vh' }}
                    data-aos="fade-in"
                >
                    <div
                        style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            background: `linear-gradient(to right, ${gradientStart}, ${gradientEnd})`,
                            opacity: 0.85,
                        }}
                    ></div>

                    <img 
                        src={houseImage} 
                        alt="House Model" 
                        className="absolute top-0 left-0 w-[200%] h-full object-cover opacity-30"
                        data-aos="zoom-in"
                    />

                    <div className="relative z-10 text-left max-w-4xl mx-auto p-8">
                        <h1 className="text-5xl font-bold leading-tight text-gray-100" data-aos="fade-right">
                            Faites le bon choix, aujourd’hui et
                        </h1>
                        <h1 className="text-5xl font-bold leading-tight text-gray-100 text-center mt-2" data-aos="fade-left">
                            <span className="inline-block w-full">pour demain.</span>
                        </h1>
                        <p className="mt-8 text-lg text-gray-200" data-aos="fade-up">
                            On est là pour vous aider dans votre achat immobilier avec nos améliorations pour prise de décision.
                        </p>

                        <div className="mt-10 flex justify-center gap-6" data-aos="fade-up" data-aos-delay="200">
                            {/* Link to Connexion page */}
                            <Link 
                                to="/connexion" 
                                className="px-12 py-4 bg-[#333] text-white font-semibold rounded-full hover:bg-white hover:text-[#333] transition duration-300"
                                onClick={handleLancerClick}
                            >
                                Lancer Vous
                            </Link>

                            {/* Link to Annonces page */}
                            <Link 
                                to="/" 
                                className="px-12 py-4 bg-[#333] text-white font-semibold rounded-full hover:bg-white hover:text-[#333] transition duration-300"
                            >
                                Parcourir
                            </Link>
                        </div>
                    </div>
                </section>

                {/* Other sections */}
                <section className="how-it-works py-20 text-center" data-aos="fade-up" data-aos-delay="100">
                    <h2 className="text-3xl font-bold mb-8">Comment ça marche ?</h2>
                    <div className="flex justify-center gap-32 mt-12">
                        <div className="max-w-xs text-center" data-aos="zoom-in" data-aos-delay="200">
                            <i className="fas fa-search text-4xl text-primary mb-4"></i>
                            <h3 className="text-xl font-semibold">Parcourez</h3>
                            <p className="text-gray-600">Notre sélection de biens immobiliers et trouvez celui qui correspond à vos besoins.</p>
                        </div>
                        <div className="max-w-xs text-center" data-aos="zoom-in" data-aos-delay="300">
                            <i className="fas fa-chart-bar text-4xl text-primary mb-4"></i>
                            <h3 className="text-xl font-semibold">Évaluez</h3>
                            <p className="text-gray-600">Évaluez le potentiel de votre achat : entrez les informations du bien dans notre outil de prédiction.</p>
                        </div>
                        <div className="max-w-xs text-center" data-aos="zoom-in" data-aos-delay="400">
                            <i className="fas fa-check-circle text-4xl text-primary mb-4"></i>
                            <h3 className="text-xl font-semibold">Décidez</h3>
                            <p className="text-gray-600">Décidez en toute confiance grâce à nos prévisions personnalisées basées sur des analyses avancées.</p>
                        </div>
                    </div>
                </section>

                <section className="prediction-section py-24 px-8 bg-gray-50 text-center lg:flex lg:justify-between lg:items-center" data-aos="fade-up" data-aos-delay="100">
                    <div className="max-w-lg text-left">
                        <h2 className="text-4xl font-bold mb-4">Notre Système de Prédiction Immobilière Basé sur le Machine Learning</h2>
                        <p className="text-gray-600 mb-8">
                            Anticipez les Prix avec Précision. Grâce à notre technologie avancée, SmartEstate offre des prévisions de prix immobiliers fiables et précises.
                        </p>
                        <div className="flex gap-4" data-aos="fade-up" data-aos-delay="200">
                            <button className="px-6 py-2 bg-black text-white rounded-full">Se lancer</button>
                            <button className="px-6 py-2 border border-gray-600 rounded-full">Read More</button>
                        </div>
                    </div>
                    <img src={predictionImage} alt="Prediction Model" className="mt-8 lg:mt-0 lg:max-w-md" data-aos="zoom-in" data-aos-delay="300" />
                </section>

                <section
                    className="newsletter-section py-16 px-8 text-center"
                    style={{ background: `linear-gradient(to right, ${gradientStart}, ${gradientEnd})` }}
                    data-aos="fade-up"
                >
                    <h2 className="text-3xl font-bold mb-4 text-white">Abonnez-vous à notre Newsletter</h2>
                    <p className="text-gray-200 mb-8">Recevez les dernières nouvelles et les prévisions immobilières directement dans votre boîte de réception.</p>
                    <form className="flex justify-center gap-4" data-aos="fade-up" data-aos-delay="200">
                        <input
                            type="email"
                            placeholder="email"
                            className="px-4 py-2 rounded-full border border-gray-300 focus:outline-none focus:ring focus:border-blue-300"
                        />
                        <button type="submit" className="px-6 py-2 bg-black text-white rounded-full">S’abonner</button>
                    </form>
                </section>
            </div>
        </div>
    );
};

export default HomePage;
