import React, { useEffect, useState } from 'react';
import Navbar from "../composants/Navbar";
import { Link } from 'react-router-dom';
import axios from 'axios';
import AOS from 'aos';
import 'aos/dist/aos.css';

const Annonces = () => {
  const token = localStorage.getItem('token');
  const [property, setPropertys] = useState([]);
  const itemsPerPage = 6;
  const [currentPage, setCurrentPage] = useState(1);
  const nb_pages = Math.ceil(property.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const dataPerPage = property.slice(startIndex, endIndex);
  
  const [maxPrice, setMaxPrice] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [adresseFilter, setAdresseFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
    fetchProperties();
  }, []);

  const fetchProperties = () => {
    axios.get('http://127.0.0.1:8000/store/annonces/')
      .then(response => {
        const propertyRequests = response.data.map(annonce =>
          axios.get(`http://127.0.0.1:8000/store/property/${annonce.Property}/`)
        );
        return Promise.all(propertyRequests);
      })
      .then(responses => {
        const propertyData = responses.map(response => response.data);
        setPropertys(propertyData);
      })
      .catch(error => {
        console.log('Error:', error);
      });
  };

  const handleFilter = () => {
    axios.get(`http://127.0.0.1:8000/store/property/`, {
      params: {
        price__gt: minPrice || undefined,
        price__lt: maxPrice || undefined,
        adress__icontains: adresseFilter || undefined,
        type_propriete: typeFilter || undefined
      }
    })
    .then(response => {
      console.log('Filter response:', response.data);
      setPropertys(response.data);
    })
    .catch(error => {
      console.error('Filter error:', error.response?.data || error);
    });
  };

  const handleFavoriteAdd = async (annonceId) => {
    try {
      const id_user = localStorage.getItem('id');
      await axios.post('http://127.0.0.1:8000/store/favoris/', {
        Customer: id_user,
        Annonce: annonceId
      });
      alert("Annonce ajoutée à la liste des favoris");
    }
    catch (error) {
      console.log("Erreur lors de l'insertion à la liste des favoris", error);
    }
  };

  const handleMinPriceChange = (e) => {
    const value = e.target.value;
    setMinPrice(value === '' ? '' : Number(value));
  };

  const handleMaxPriceChange = (e) => {
    const value = e.target.value;
    setMaxPrice(value === '' ? '' : Number(value));
  };

  return (
    <div className='flex flex-col gap-20 pt-20' data-aos="fade-in">
      <Navbar />
      
      <div className="p-8 flex flex-col gap-8 max-w-6xl mx-auto" data-aos="fade-up">
        <h2 className='text-gray-600 text-xl font-bold text-center mb-6'>Filtrer les annonces</h2>
        
        {/* Filter Section */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8" data-aos="fade-right">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div className="flex flex-col">
              <label className="text-gray-600 font-semibold mb-1">Prix inférieur à :</label>
              <input
                type="number"
                className="p-2 border border-gray-300 rounded-full text-gray-600 outline-none focus:border-[#333]"
                placeholder="Le prix maximum en DA"
                value={maxPrice}
                onChange={handleMaxPriceChange}
                min="0"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-gray-600 font-semibold mb-1">Prix supérieur à :</label>
              <input
                type="number"
                className="p-2 border border-gray-300 rounded-full text-gray-600 outline-none focus:border-[#333]"
                placeholder="Prix minimum en DA"
                value={minPrice}
                onChange={handleMinPriceChange}
                min="0"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-gray-600 font-semibold mb-1">Adresse :</label>
              <input
                type="text"
                className="p-2 border border-gray-300 rounded-full text-gray-600 outline-none focus:border-[#333]"
                placeholder="L'adresse de l'annonce"
                value={adresseFilter}
                onChange={(e) => setAdresseFilter(e.target.value.trim())}
              />
            </div>
            <div className="flex flex-col">
              <label className="text-gray-600 font-semibold mb-1">Type de propriété :</label>
              <select
                className="p-2 border border-gray-300 rounded-full text-gray-600 outline-none focus:border-[#333] cursor-pointer"
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
              >
                <option value="">Tous les types</option>
                <option value="Appartement">Appartement</option>
                <option value="Villa">Villa</option>
                <option value="Terrain">Terrain</option>
              </select>
            </div>
            <button 
              onClick={handleFilter}
              className="px-6 py-2 bg-[#333] text-white font-bold rounded-full mt-4 sm:mt-0 hover:bg-opacity-90 transition"
            >
              Appliquer les filtres
            </button>
          </div>
        </div>

        {/* Centered Ajouter Annonce Button */}
        {token && (
          <div className="flex justify-center" data-aos="fade-left">
            <div className="p-3 rounded-full bg-[#333] text-white font-bold items-center cursor-pointer w-max hover:bg-white hover:text-[#333] border border-transparent hover:border-[#333] transition">
              <Link to="/ajouter_annonce">Ajouter Annonce</Link>
            </div>
          </div>
        )}
      </div>

      {/* Listings Section */}
      {property.length === 0 && (
        <span className='text-gray-600 font-bold flex justify-center text-xl' data-aos="fade-up">
          Aucune Annonce n'a été trouvée
        </span>
      )}
      {property.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mx-8 pb-8">
          {dataPerPage.map((prop, i) => (
            <div key={i} className='flex flex-col bg-white rounded-lg shadow-md overflow-hidden transition transform hover:scale-105' data-aos="zoom-in">
              <div className="relative">
                <img className="w-full h-40 object-cover" src={prop.img_3} alt="Property" />
                {token && (
                  <button 
                    onClick={() => handleFavoriteAdd(prop.id)}
                    className="absolute top-2 right-2 p-2 bg-white rounded-full shadow hover:bg-[#333] transition-all"
                  >
                    <i className='fa-solid fa-heart text-gray-400 hover:text-white transform transition-transform duration-200 ease-out hover:scale-125'></i>
                  </button>
                )}
              </div>
              <div className="p-4">
                <span className='text-xs text-gray-500 font-semibold'>Location</span>
                <h3 className='text-lg font-bold text-gray-800 mt-1'>{prop.title}</h3>
                <p className='text-sm text-gray-500'>{prop.adress}</p>
                <p className='text-gray-700 mt-2'>Surface: {prop.area} m²</p>
                <p className='text-gray-700 font-semibold text-lg mt-2'>Prix: {prop.price} DA</p>
                <Link 
                  to={`/annonces/annonce/${prop.id}`}
                  className="block text-center mt-4 py-2 px-4 bg-[#333] text-white font-bold rounded-full transition hover:bg-white hover:text-[#333] hover:border-[#333] border border-transparent"
                >
                  Voir plus
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      <ul className="flex justify-center gap-2 mb-8" data-aos="fade-up">
        {Array.from({ length: nb_pages }, (_, i) => (
          <button 
            key={i + 1}
            className={`font-bold rounded-full h-9 w-9 ${currentPage === i + 1 ? 'bg-[#333] text-white' : 'bg-gray-300 text-gray-700'} hover:bg-[#333] hover:text-white transition`}
            onClick={() => setCurrentPage(i + 1)}
          >
            {i + 1}
          </button>
        ))}
      </ul>
    </div>
  );
};

export default Annonces;
