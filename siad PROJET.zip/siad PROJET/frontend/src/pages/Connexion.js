import React, { useEffect, useState } from 'react';
import Navbar from "../composants/Navbar";
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useForm } from "react-hook-form";
import AOS from 'aos';
import 'aos/dist/aos.css';
import backgroundImage from '../assets/vecteezy_dark-abstract-background-black-overlap-vector_10630941.jpg';

const Connexion = () => {
  const { handleSubmit, register, formState: { errors } } = useForm();
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  const onSubmit = async (data) => {
    try {
      const response = await axios.post('http://127.0.0.1:8000/auth/jwt/create/', data);
      const token = response.data.access;
      localStorage.setItem('token', token);
      setErrorMessage('');
      navigate('/');
    } catch (error) {
      if (error.response && error.response.status === 401) {
        setErrorMessage("Nom d'utilisateur ou mot de passe incorrects");
      } else if (error.request) {
        setErrorMessage("Pas de réponse du serveur");
      } else {
        setErrorMessage("Erreur de configuration de la requête: " + error.message);
      }
    }
  };

  return (
    <div style={styles.container}>
      <Navbar />
      <style>
        {`
          .login-button {
            width: 100%;
            padding: 12px;
            background-color: #333;
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 12px;
            transition: background-color 0.3s, transform 0.3s;
          }
          .login-button:hover {
            background-color: #555;
            transform: scale(1.05);
          }
        `}
      </style>
      <div style={styles.loginContainer} data-aos="fade-up">
        <div style={styles.illustrationSection} data-aos="fade-right">
          <img 
            src={require("../assets/24070702_bwink_bld_03_single_03-removebg-preview.png")}
            alt="Illustration"
            style={styles.illustrationImage}
          />
        </div>
        <div style={styles.formSection} data-aos="fade-left">
          <form onSubmit={handleSubmit(onSubmit)} style={styles.form}>
            <div style={styles.header}>
              <h1 style={styles.title} data-aos="fade-down" data-aos-delay="200">Bienvenue!</h1>
              <p style={styles.subtitle} data-aos="fade-down" data-aos-delay="400">Veuillez remplir le formulaire</p>
            </div>
            {errorMessage && <p style={styles.errorMessage} data-aos="fade-down" data-aos-delay="600">{errorMessage}</p>}

            <div style={styles.inputGroup} data-aos="fade-up" data-aos-delay="400">
              <label style={styles.label}>Nom d'utilisateur</label>
              <input
                type="text"
                {...register("username", { required: "Ce champ est requis", minLength: { value: 4, message: "Au moins 4 caractères" } })}
                placeholder="Tapez votre nom d'utilisateur..."
                style={styles.input}
              />
              {errors.username && <p style={styles.errorText}>{errors.username.message}</p>}
            </div>

            <div style={styles.inputGroup} data-aos="fade-up" data-aos-delay="600">
              <label style={styles.label}>Mot de passe</label>
              <input
                type="password"
                {...register("password", { required: "Ce champ est requis", minLength: { value: 1, message: "Au moins 1 caractère" } })}
                placeholder="Tapez votre mot de passe..."
                style={styles.input}
              />
              {errors.password && <p style={styles.errorText}>{errors.password.message}</p>}
            </div>

            <div style={styles.options} data-aos="fade-up" data-aos-delay="800">
              <label style={styles.rememberMe}>
                <input type="checkbox" />
                Se souvenir de moi
              </label>
            </div>

            <button type="submit" className="login-button" data-aos="zoom-in" data-aos-delay="1000">Connexion</button>

            <p style={styles.signupPrompt} data-aos="fade-up" data-aos-delay="1200">
              Vous n'avez pas de compte ? <Link to="/inscription" style={styles.signupLink}>Cliquez ici</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

// Inline styles
const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
  },
  loginContainer: {
    display: 'flex',
    backgroundColor: '#f9f9f9',
    borderRadius: '16px',
    overflow: 'hidden',
    width: '800px',
    maxWidth: '90%',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
  },
  illustrationSection: {
    width: '50%',
    backgroundColor: '#ececec',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
  },
  illustrationImage: {
    width: '100%',
    maxWidth: '500px',
    borderRadius: '8px',
  },
  formSection: {
    width: '50%',
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    backdropFilter: 'blur(10px)',
    borderRadius: '16px',
  },
  form: {
    width: '100%',
  },
  header: {
    textAlign: 'center',
    marginBottom: '20px',
  },
  title: {
    fontSize: '24px',
    color: '#333',
    marginBottom: '5px',
  },
  subtitle: {
    color: '#777',
  },
  inputGroup: {
    marginBottom: '16px',
  },
  label: {
    fontSize: '14px',
    color: '#555',
    display: 'block',
    marginBottom: '5px',
  },
  input: {
    width: '100%',
    padding: '12px',
    fontSize: '14px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    outline: 'none',
    transition: 'border-color 0.3s',
  },
  options: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontSize: '12px',
    marginBottom: '20px',
  },
  rememberMe: {
    display: 'flex',
    alignItems: 'center',
  },
  signupPrompt: {
    textAlign: 'center',
    fontSize: '12px',
    marginTop: '20px',
    color: '#777',
  },
  signupLink: {
    color: '#333',
    textDecoration: 'none',
    fontWeight: 'bold',
  },
  errorMessage: {
    color: '#d9534f',
    fontSize: '12px',
    marginBottom: '10px',
  },
  errorText: {
    color: '#d9534f',
    fontSize: '12px',
    marginTop: '5px',
  },
};

export default Connexion;
