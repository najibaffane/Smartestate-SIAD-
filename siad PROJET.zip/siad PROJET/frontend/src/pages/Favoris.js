import React, { useEffect, useState } from 'react';
import Navbar from '../composants/Navbar';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const Favoris = () => {
    const { userId } = useParams();
    const userIdInt = parseInt(userId);
    const [favoris, setfavoris] = useState([]);
    const [property, setPropertys] = useState([]);
    const [supprimerSucces, setSuprrimerSucces] = useState("");

    const fetchData = async () => {
        try {
            const favoris_resp = await axios.get('http://127.0.0.1:8000/store/favoris/');
            const favoris_id = favoris_resp.data.filter(itm_favoris => itm_favoris.Customer === userIdInt);
            setfavoris(favoris_id);
            try {
                const propertysPromises = favoris_id.map(favoris_annonce =>
                    axios.get(`http://127.0.0.1:8000/store/property/${favoris_annonce.Annonce}/`)
                );
                const propertysRes = await Promise.all(propertysPromises);
                const propertysData = propertysRes.map(response => response.data);
                setPropertys(propertysData);
            } catch (error) {
                console.log("Erreur de la récupération des propriétés", error);
            }
        } catch (error) {
            console.log("Erreur de la récupération des favoris");
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleDeleteFavoris = async (annonceId) => {
        const favori = favoris.find(favori => favori.Annonce === annonceId);
        try {
            const response = await axios.delete(`http://127.0.0.1:8000/store/favoris/${favori.id}/`);
            if (response.status === 204) {
                fetchData();
                setSuprrimerSucces("L'annonce a été bien supprimée de la liste des favoris");
            }
        } catch (error) {
            console.log("Erreur de la suppresion de l'annonce", error);
        }
    };

    return (
        <div className="flex flex-col gap-20 bg-gray-100 min-h-screen pt-16">
            <Navbar />
            <div className="p-8 flex flex-col gap-6">
                <h2 className="text-[#333] font-bold text-3xl text-center">Ma liste des favoris</h2>
                {property.length === 0 && (
                    <span className="text-red-600 font-bold text-center text-2xl">
                        Vous n'avez pas des annonces favorisées !
                    </span>
                )}
                {supprimerSucces && (
                    <span className="text-green-500 bg-green-100 p-3 text-center font-semibold rounded-md">
                        {supprimerSucces}
                    </span>
                )}
            </div>
            {property.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mx-auto w-full max-w-screen-xl p-4">
                    {property.map((prop, i) => (
                        <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                            <div className="h-48 overflow-hidden">
                                <img
                                    className="w-full h-full object-cover"
                                    src={prop.img_3}
                                    alt={`${prop.title} property`}
                                />
                            </div>
                            <div className="p-6 flex flex-col justify-between">
                                <h3 className="text-lg font-semibold text-[#333] mb-2">
                                    {prop.title}, {prop.adress}
                                </h3>
                                <div className="text-gray-600 text-sm mb-4">Surface : {prop.area} m²</div>
                                <div className="text-[#333] font-bold text-xl mb-6">Prix : {prop.price} DA</div>
                                <div className="flex flex-row gap-4">
                                    <Link
                                        className="flex-1 p-2 text-center font-semibold bg-[#333] text-white rounded-md transition-all duration-300 hover:bg-white hover:text-[#333] hover:border-[#333] border"
                                        to={`/annonces/annonce/${prop.id}`}
                                    >
                                        Voir plus
                                    </Link>
                                    <button
                                        onClick={() => handleDeleteFavoris(prop.id)}
                                        className="flex-1 p-2 text-center font-semibold bg-red-500 text-white rounded-md transition-all duration-300 hover:bg-white hover:text-red-500 border hover:border-red-500"
                                    >
                                        Supprimer
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Favoris;
