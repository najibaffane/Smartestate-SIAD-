import React from 'react';
import Navbar from '../composants/Navbar';
import Annonces from './Annonces';
const Acceuil = () => {
    return (
        <div>
            <Navbar />
            <Annonces/>
            
        </div>

    );
};
export default Acceuil;
