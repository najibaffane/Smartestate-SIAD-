import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Navbar from '../composants/Navbar';
import axios from 'axios';

const Mes_annonces = () => {
  const { userId } = useParams();
  const userIdInt = parseInt(userId);
  const [annonces, setAnnonces] = useState([]);
  const [property, setPropertys] = useState([]);
  const [supprimerSucces, setSuprrimerSucces] = useState("");
  const [input_etat, setIputEtat] = useState("");

  const handleEtatChange = (event) => {
    setIputEtat(event.target.value);
  };

  const fetchData = async () => {
    setSuprrimerSucces("");
    try {
      const annonces_resp = await axios.get('http://127.0.0.1:8000/store/annonces/');
      const annoncesData = annonces_resp.data.filter(itm_annonce => itm_annonce.Customer === userIdInt);
      setAnnonces(annoncesData);
      try {
        const propertysPromises = annoncesData.map(annonce =>
          axios.get(`http://127.0.0.1:8000/store/property/${annonce.Property}/`)
        );
        const propertysRes = await Promise.all(propertysPromises);
        const propertysData = propertysRes.map(response => response.data);
        setPropertys(propertysData);
      } catch (error) {
        console.log("Erreur de la récupération des propertys", error);
      }
    } catch (error) {
      console.log("Erreur de la récupération des annonces", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleUpdateAnnonce = async (annonceId) => {
    if (input_etat === "") {
      alert("L'annonce est déjà dans cet état ");
    }
    try {
      const response = await axios.patch(`http://127.0.0.1:8000/store/property/${annonceId}/`, {
        state: input_etat,
      });
      if (response.status === 200) {
        fetchData();
        setSuprrimerSucces("Annonce a été modifiée avec succès !");
      }
    } catch (error) {
      console.log("Erreur de la modification d'une annonce", error);
    }
  };

  const handleDeleteAnnonce = async (annonceId) => {
    try {
      const response = await axios.delete(`http://127.0.0.1:8000/store/property/${annonceId}/`);

      if (response.status === 204) {
        fetchData();
        setSuprrimerSucces("L'annonce a été supprimée avec succès");
      }
    } catch (error) {
      console.log("Erreur de la suppresion de l'annonce", error);
    }
  };

  return (
    <div className="flex flex-col gap-10 bg-gray-100 min-h-screen">
      <Navbar />
      <div className="p-8">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">Mes annonces</h2>
        {annonces.length === 0 && (
          <p className="text-center text-xl text-red-500 font-semibold">
            Vous n'avez aucune annonce !
          </p>
        )}
        {supprimerSucces && (
          <p className="text-center text-lg font-semibold text-green-600 bg-green-100 p-3 rounded-md">
            {supprimerSucces}
          </p>
        )}
      </div>
      {property.length > 0 && (
        <div className="flex flex-col gap-6 mx-auto w-full max-w-5xl p-4">
          {property.map((prop, i) => (
            <div
              key={i}
              className="flex items-center bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow duration-300"
            >
              <img
                className="w-48 h-32 object-cover rounded-md"
                src={prop.img_3}
                alt={prop.title}
              />
              <div className="flex-grow pl-6">
                <h3 className="text-lg font-semibold text-gray-800">
                  {prop.title}, {prop.adress}
                </h3>
                <p className="text-sm text-gray-600">Surface: {prop.area} m²</p>
                <p className="text-md font-semibold text-gray-800">Prix: {prop.price} DA</p>
              </div>
              <div className="flex flex-col items-center gap-2">
                <Link
                  to={`/annonces/annonce/${prop.id}`}
                  className="w-24 text-center p-2 rounded-full font-semibold text-white bg-gray-800 hover:bg-gray-700 transition"
                >
                  Voir plus
                </Link>
                <button
                  className="w-24 text-center p-2 rounded-full font-semibold text-white bg-red-500 hover:bg-red-600 transition"
                  onClick={() => handleDeleteAnnonce(prop.id)}
                >
                  Supprimer
                </button>
                <select
                  className="w-24 p-2 rounded-full bg-gray-100 border border-gray-300 cursor-pointer"
                  onChange={handleEtatChange}
                  value={input_etat || prop.state}
                >
                  <option disabled>L'état</option>
                  <option value="DISPONIBLE">Disponible</option>
                  <option value="VENDUE">Vendue</option>
                  <option value="ARCHIVE">Archivé</option>
                  <option value="EN_ATTENTE">En attente</option>
                </select>
                <button
                  className="w-24 text-center p-2 rounded-full font-semibold text-white bg-green-500 hover:bg-green-600 transition"
                  onClick={() => handleUpdateAnnonce(prop.id)}
                >
                  Modifier
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Mes_annonces;
