import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Logo from "../../src/assets/2-removebg-preview.png";
import axios from 'axios';

const header_lien = [
    { name: "Listing", link: "/" },
    { name: "Prediction", link: "/estimation_des_prix_appartements" },
    { name: "Accueil", link: "/home" },
];

const Navbar = () => {
    const [userData, setUserData] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const token = localStorage.getItem('token');
                if (!token) return;
                const response = await axios.get('http://127.0.0.1:8000/auth/users/me/', {
                    headers: { Authorization: `JWT ${token}` },
                });
                setUserData(response.data);
                localStorage.setItem('id', response.data.id);
            } catch (error) {
                console.error('Failed to fetch user data:', error);
            }
        };
        fetchData();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('id');
        setUserData(null);
        navigate('/home');
    };

    return (
        <nav className="w-full py-2 bg-white fixed top-0 border-b shadow-md z-50">
            <div className="flex justify-between items-center mx-4 max-w-full h-16">
                
                {/* Logo agrandi et collé à gauche */}
                <div className="flex items-center">
                    <img src={Logo} alt="Navbar_logo" className="h-100 w-40" />
                </div>
                
                {/* Liens de menu centrés avec les liens d'origine */}
                <ul className="flex gap-10 text-gray-700 font-semibold">
                    {header_lien.map((menu, i) => (
                        <li key={i} className="relative group">
                            <Link 
                                to={menu.link} 
                                className="px-2 py-2 relative transition-all duration-300 ease-in-out text-gray-700 hover:text-[#333] font-semibold"
                            >
                                {menu.name}
                                {/* Pseudo-element for the larger hover effect */}
                                <span className="absolute inset-0 rounded-full scale-0 group-hover:scale-150 transition-transform duration-300 ease-in-out bg-gray-200 opacity-50"></span>
                            </Link>
                        </li>
                    ))}
                </ul>

                {/* Boutons à droite avec amélioration de hover */}
                <div className="flex gap-4 items-center">
                    {!userData ? (
                        <>
                            <Link to="/inscription" className="font-bold text-gray-600 hover:underline hover:text-[#333] transition duration-300 ease-in-out">
                                Inscrivez-vous
                            </Link>
                            <Link to="/connexion" className="border-2 border-gray-300 rounded-full px-4 py-2 transition-all duration-300 ease-in-out hover:bg-gray-200 hover:shadow-md hover:scale-105 font-bold text-gray-600">
                                Se connecter
                            </Link>
                        </>
                    ) : (
                        <div className="flex items-center gap-4">
                            <span className="font-semibold text-gray-700">
                                Bonjour, {userData.first_name || "Utilisateur"}
                            </span>
                            <div className="relative group">
                                <button className="flex items-center px-4 py-2 border-2 border-gray-300 rounded-full transition-all duration-300 ease-in-out hover:bg-gray-200 hover:shadow-md font-bold text-gray-600">
                                    Mon Compte
                                </button>
                                {/* Dropdown Menu for Account */}
                                <ul className="absolute right-0 mt-2 w-48 bg-white border rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-in-out z-50">
                                    <li>
                                        <Link to={`/utilisateur/mon_profil/${userData.id}`} className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                            Mon Profil
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to={`/mes_annonces/utilisateur/${userData.id}`} className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                            Mes Annonces
                                        </Link>
                                    </li>
                                    <li>
                                        <button onClick={handleLogout} className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                                            Se Déconnecter
                                        </button>
                                    </li>
                                </ul>
                            </div>

                            {/* Favorites Button */}
                            <Link to={`/mes_favoris/utilisateur/${userData.id}`} className="text-gray-600 hover:text-red-500 transition-all duration-300 ease-in-out">
                                <i className="fas fa-heart text-2xl"></i>
                            </Link>
                        </div>
                    )}
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
