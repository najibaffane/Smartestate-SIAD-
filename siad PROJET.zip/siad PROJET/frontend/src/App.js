import React, { useEffect } from 'react';
import './App.css'; // Adjust the path if needed
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';

// Import all the pages/components
import Acceuil from './pages/Acceuil';
import Connexion from './pages/Connexion';
import Inscription from './pages/Inscription';
import Annonce from './pages/Annonce';
import Ajouter_Annonce from './pages/Ajouter_Annonce';
import Mes_annonces from './pages/Mes_annonces';
import Estimateur from './pages/Estimateur';
import Favoris from './pages/Favoris';
import Profil from './pages/Profil';
import HomePage from './pages/home';

const App = () => {
  useEffect(() => {
    AOS.init({ duration: 1000, once: true }); // Initialize AOS with options
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Acceuil />} />
        <Route path="/connexion" element={<Connexion />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/inscription" element={<Inscription />} />
        <Route path="/ajouter_annonce" element={<Ajouter_Annonce />} />
        <Route path="/annonces/annonce/:id" element={<Annonce />} />
        <Route path="/mes_annonces/utilisateur/:userId" element={<Mes_annonces />} />
        <Route path="/utilisateur/mon_profil/:userId" element={<Profil />} />
        <Route path="/estimation_des_prix_appartements" element={<Estimateur />} />
        <Route path="/mes_favoris/utilisateur/:userId" element={<Favoris />} />
        {/* Uncomment if you have a general error page */}
        {/* <Route path="*" element={<Erreur />} /> */}
      </Routes>
    </BrowserRouter>
  );
};

export default App;
